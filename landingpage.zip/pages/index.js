export default function Home(){
  return (<main><h1>Landing Page</h1><p>Bienvenido</p></main>);
 }