// conferences placeholder
